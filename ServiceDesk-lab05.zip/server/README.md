# ServiceDesk.API (Lab 05)

Backend проекта Service Desk.

Lab 05 добавляет основной домен системы — тикеты.

## Что нового относительно Lab 04

### Tickets
- модель Ticket
- статусы: New, InProgress, Resolved, Closed, Rejected
- создание тикета (Student)
- просмотр тикетов (Student — только свои)
- фильтрация

### API
- POST /api/tickets
- GET /api/tickets
- GET /api/tickets/{id}

### Правила
- Student видит только свои тикеты
- статус управляется backend
