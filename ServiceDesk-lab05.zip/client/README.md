# Service Desk Client (Lab 05)

Клиентская часть проекта Service Desk.

Lab 05 добавляет полноценный функционал работы с тикетами для роли Student.

## Что нового относительно Lab 04

### Tickets (Student)
- список тикетов пользователя
- создание тикета
- просмотр деталей тикета
- фильтрация

### API интеграция
- GET /api/tickets
- POST /api/tickets
- GET /api/tickets/{id}

### UI
- TicketsPage
- NewTicketPage
- TicketDetailPage

## Архитектура
- TanStack Query для загрузки данных
- разделение по ролям сохранено
