# Service Desk Client

Клиентская часть учебного проекта **Service Desk**.

Фронтенд реализован на **React 18 + TypeScript + Vite + Ant Design + TanStack Query + React Router** и предназначен для работы с backend API проекта. На текущем этапе клиент покрывает:
- аутентификацию и регистрацию;
- инициализацию текущего пользователя по JWT;
- защищённые маршруты и разграничение доступа по ролям;
- административные страницы категорий и пользователей;
- базовые общие UI-состояния: loading, empty, error, 404, forbidden.

## Стек технологий

- React 18
- TypeScript
- Vite
- Ant Design 5
- TanStack Query v5
- React Router v6
- ESLint 9
- Prettier 3

## Требования

- Node.js 20+
- npm 10+
- запущенный backend Service Desk API

## Установка и запуск

Из папки `client`:

```bash
npm install
npm run dev
```

Приложение будет доступно по адресу:

```text
http://localhost:5173
```

## Подключение к backend

Во время локальной разработки запросы вида `/api/*` проксируются через Vite на backend:

```ts
// vite.config.ts
proxy: {
  '/api': 'http://localhost:5051',
}
```

Это значит, что backend должен быть запущен на:

```text
http://localhost:5051
```

Клиент использует относительный базовый URL и отправляет запросы через встроенный fetch-обёртку в `src/api/client.ts`.

## Доступные команды

```bash
npm run dev      # запуск dev-сервера
npm run build    # production build
npm run preview  # локальный просмотр production build
npm run lint     # проверка eslint
npm run format   # форматирование src через prettier
```

## Структура проекта

```text
client/
├─ src/
│  ├─ api/                # HTTP client и ApiError
│  ├─ app/                # корневой редирект
│  ├─ components/         # layout, guards, page states
│  ├─ contexts/           # AuthContext
│  ├─ pages/              # страницы приложения
│  │  ├─ admin/           # admin pages
│  │  ├─ operator/        # operator pages
│  │  └─ student/         # student pages
│  ├─ App.tsx             # маршрутизация
│  └─ main.tsx            # точка входа
├─ .env.example
├─ index.html
├─ package.json
├─ tsconfig.json
└─ vite.config.ts
```

## Аутентификация

Аутентификация построена на JWT access token:
- после успешного входа или регистрации токен сохраняется в `localStorage` по ключу `token`;
- при инициализации приложения выполняется запрос `GET /api/auth/me`;
- если токен невалиден или backend недоступен, выполняется logout;
- токен автоматически добавляется в заголовок `Authorization: Bearer ...` для всех API-запросов.

Основная логика находится в:
- `src/contexts/AuthContext.tsx`
- `src/api/client.ts`

## Роли и маршруты

В приложении используются три роли:
- `Student`
- `Operator`
- `Admin`

Защита маршрутов реализована двумя компонентами:
- `RequireAuth` — проверяет факт авторизации;
- `RequireRole` — проверяет, что роль пользователя входит в список разрешённых.

Также используется `RootRedirect`, который перенаправляет авторизованного пользователя на стартовую страницу по роли.

### Публичные маршруты

- `/login` — вход
- `/register` — регистрация

### Приватные маршруты

#### Student
- `/tickets`
- `/tickets/new`
- `/tickets/:id`

#### Operator
- `/queue/new`
- `/queue/assigned`
- `/queue/resolved`
- `/tickets/:id`

#### Admin
- `/admin/categories`
- `/admin/users`

## Что реализовано

### 1. Аутентификация

Реализованы страницы:
- `LoginPage`
- `RegisterPage`

Поддерживается:
- отправка данных на backend;
- вывод ошибок API;
- автоматический редирект после входа по роли пользователя:
  - `Student` → `/tickets`
  - `Operator` → `/queue/new`
  - `Admin` → `/admin/categories`

### 2. Общий layout приложения

`AppLayout` содержит:
- верхнюю панель с названием проекта;
- отображение `displayName` и текущей роли;
- кнопку Logout;
- левое меню, зависящее от роли пользователя;
- область для контента страницы через `Outlet`.

### 3. Администрирование категорий

Страница: `src/pages/admin/CategoriesPage.tsx`

Поддерживает:
- загрузку списка категорий;
- создание категории;
- редактирование названия;
- переключение активности категории;
- обработку loading/error/empty состояний;
- уведомления через Ant Design `message`.

Используемые API:
- `GET /api/categories?includeInactive=true`
- `POST /api/categories`
- `PUT /api/categories/{id}`
- `PATCH /api/categories/{id}/active`

### 4. Администрирование пользователей и ролей

Страница: `src/pages/admin/UsersPage.tsx`

Поддерживает:
- загрузку списка пользователей;
- просмотр `displayName`, `email`, `role`;
- смену роли через `PUT /api/users/{id}/role`;
- локальный выбор роли до нажатия Save;
- уведомление о том, что новая роль применяется после следующего входа.

Используемый API:
- `GET /api/users`
- `PUT /api/users/{id}/role`

### 5. Базовые UI-состояния

Вынесены отдельные компоненты:
- `PageLoading`
- `PageEmpty`
- `PageError`
- `PageValidation`
- `PageNotFound`
- `ForbiddenPage`

Это упрощает единообразное поведение страниц.

## Что пока является заготовкой

На текущем этапе следующие страницы существуют как заглушки и не содержат полной бизнес-логики:
- `src/pages/student/TicketsPage.tsx`
- `src/pages/student/NewTicketPage.tsx`
- `src/pages/TicketDetailPage.tsx`
- `src/pages/operator/QueueNewPage.tsx`
- `src/pages/operator/QueueAssignedPage.tsx`
- `src/pages/operator/QueueResolvedPage.tsx`

То есть клиентская часть уже готова для:
- auth flow;
- проверки guards и layout;
- работы администратора с категориями и ролями;

но ещё не завершена для полноценного ticket workflow студента и оператора.

## Обработка ошибок API

Клиент ожидает от backend ответы в формате ProblemDetails.

Если запрос завершается ошибкой:
- HTTP status сохраняется в `ApiError.status`;
- текст ошибки берётся из `detail`, затем из `title`;
- если тело не распарсилось, используется fallback вида `HTTP 400`, `HTTP 401` и т.д.

Это поведение реализовано в `src/api/client.ts`.

## Особенности текущей реализации

- Базовый URL API в клиенте пустой (`const BASE_URL = ''`), потому что в dev-режиме используется proxy Vite.
- Состояние авторизации хранится в `AuthContext`, а серверные данные страниц — через TanStack Query.
- Меню в layout строится по текущей роли.
