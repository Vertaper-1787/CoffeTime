# ServiceDesk.API

Серверная часть учебного проекта **Service Desk** на **ASP.NET Core 8**.

Текущее состояние архива соответствует backend-части **Lab 04**:
- аутентификация и авторизация через **JWT**
- пользователи и роли через **ASP.NET Core Identity**
- управление категориями
- административное изменение роли пользователя
- Swagger для ручной проверки API
- глобальная обработка ошибок в формате **ProblemDetails**

## Стек

- ASP.NET Core 8 Web API
- ASP.NET Core Identity
- Entity Framework Core 8
- SQL Server
- JWT Bearer Authentication
- Swagger / OpenAPI

## Возможности

### Auth
- `POST /api/auth/register` — регистрация нового пользователя
- `POST /api/auth/login` — вход по email и password
- `GET /api/auth/me` — профиль текущего пользователя по Bearer token

### Categories
- `GET /api/categories` — список категорий
- `POST /api/categories` — создать категорию (**Admin**)
- `PUT /api/categories/{id}` — переименовать категорию (**Admin**)
- `PATCH /api/categories/{id}/active` — включить/выключить категорию (**Admin**)

Особенности:
- **Student** всегда получает только активные категории
- **Operator/Admin** могут передать `includeInactive=true`, чтобы увидеть все категории

### Users / Roles
- `GET /api/users` — список пользователей с текущей ролью (**Admin**)
- `PUT /api/users/{id}/role` — изменить роль пользователя (**Admin**)

Поддерживаемые роли:
- `Student`
- `Operator`
- `Admin`

Важно:
- роль в JWT берётся на момент логина
- после изменения роли новый доступ вступает в силу **при следующем входе**

### Health
- `GET /health` — проверка доступности API

## Архитектура проекта

```text
server/
├─ ServiceDesk.sln
└─ ServiceDesk.API/
   ├─ Application/
   │  ├─ Mapping/
   │  └─ Services/
   ├─ Controllers/
   ├─ DTOs/
   │  ├─ Auth/
   │  ├─ Categories/
   │  └─ Users/
   ├─ Domain/
   ├─ Exceptions/
   ├─ Infrastructure/
   │  ├─ Auth/
   │  ├─ Data/
   │  └─ Seed/
   ├─ Middleware/
   ├─ Migrations/
   ├─ Program.cs
   ├─ appsettings.json
   └─ appsettings.Development.json
```

## Основные правила реализации

- контроллеры остаются тонкими, бизнес-логика вынесена в сервисы
- ошибки API возвращаются в формате **ProblemDetails (RFC 7807)**
- `401` возвращается для отсутствующего/невалидного JWT
- `403` возвращается при недостаточных правах
- `400` используется для ошибок валидации и бизнес-правил
- `404` используется для отсутствующих сущностей
- логирование выполняется через `ILogger<T>`

## Конфигурация

Пример настроек из `appsettings.Development.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=.\\SQLEXPRESS;Database=servicedesk;Integrated Security=True;TrustServerCertificate=True;MultipleActiveResultSets=True;",
    "DefaultConnection_2": "Host=localhost;Port=5432;Database=servicedesk;Username=postgres;Password=postgres"
  },
  "Jwt": {
    "Key": "dev-secret-key-1234567890-1234567890",
    "Issuer": "ServiceDesk",
    "Audience": "ServiceDesk.Client",
    "ExpiresMinutes": 60
  }
}
```

Сейчас в `Program.cs` активна конфигурация **SQL Server** через `UseSqlServer(...)`.
Строка `DefaultConnection_2` для PostgreSQL присутствует в development-настройках, но закомментирована и не используется.

Требования к JWT-конфигурации:
- `Jwt:Key` обязателен
- длина ключа должна быть не меньше **32** символов
- `Jwt:Issuer` обязателен
- `Jwt:Audience` обязателен

Если `Jwt:Key` не задан или пустой в конфигурации, приложение пытается взять значение из переменной окружения `JWT_KEY`.

## Запуск проекта

### 1. Перейти в папку сервера

```bash
cd server
```

### 2. Восстановить зависимости

```bash
dotnet restore
```

### 3. Проверить строку подключения и JWT-настройки

Отредактировать:
- `ServiceDesk.API/appsettings.Development.json`

### 4. Применить миграции

```bash
dotnet ef database update --project ServiceDesk.API
```

### 5. Запустить API

```bash
dotnet run --project ServiceDesk.API
```

После запуска в Development обычно доступны:
- Swagger UI: `http://localhost:5051/swagger`
- Health: `http://localhost:5051/health`

Также в `launchSettings.json` есть HTTPS-профиль с адресом `https://localhost:7033`.

## Seed-данные

В Development при старте выполняется инициализация ролей и демонстрационных данных.

Создаются роли:
- `Student`
- `Operator`
- `Admin`

Создаются demo-пользователи:
- `admin@demo.com` / `Admin123!`
- `operator1@demo.com` / `Operator123!`
- `operator2@demo.com` / `Operator123!`
- `student1@demo.com` / `Student123!`
- `student2@demo.com` / `Student123!`
- `student3@demo.com` / `Student123!`

Создаются demo-категории:
- Hardware Issues
- Software Issues
- Network Problems
- Account Management
- Security Concerns

## Swagger

В Development включён Swagger с поддержкой Bearer authentication.

Как проверить защищённые endpoints:
1. выполнить `POST /api/auth/login` или `POST /api/auth/register`
2. скопировать `accessToken`
3. нажать **Authorize** в Swagger
4. вставить токен
5. вызвать защищённые endpoints

## Формат ответов и ошибок

### Успешный ответ авторизации

```json
{
  "accessToken": "<jwt>"
}
```

### Пример `ProblemDetails`

```json
{
  "type": "about:blank",
  "title": "Unauthorized",
  "status": 401,
  "detail": "A valid Bearer token is required.",
  "instance": "/api/auth/me"
}
```

## Примеры запросов

### Регистрация

```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "student4@demo.com",
  "password": "Student123!",
  "displayName": "Student Four"
}
```

### Логин

```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@demo.com",
  "password": "Admin123!"
}
```

### Создание категории

```http
POST /api/categories
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Printers"
}
```

### Изменение роли пользователя

```http
PUT /api/users/{id}/role
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "role": "Operator"
}
```
