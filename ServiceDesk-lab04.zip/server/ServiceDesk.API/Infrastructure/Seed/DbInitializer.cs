using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ServiceDesk.API.Domain;
using ServiceDesk.API.Infrastructure.Data;

namespace ServiceDesk.API.Infrastructure.Seed;

public static class DbInitializer
{
    private record SeedUser(string Email, string Password, string DisplayName, string Role);

    private static readonly SeedUser[] Users =
    [
        new("admin@demo.com",     "Admin123!",    "Admin",         "Admin"),
        new("operator1@demo.com", "Operator123!", "Operator One",  "Operator"),
        new("operator2@demo.com", "Operator123!", "Operator Two",  "Operator"),
        new("student1@demo.com",  "Student123!",  "Student One",   "Student"),
        new("student2@demo.com",  "Student123!",  "Student Two",   "Student"),
        new("student3@demo.com",  "Student123!",  "Student Three", "Student"),
    ];

    private static readonly (string Name, bool IsActive)[] Categories =
    [
        ("Hardware Issues",     true),
        ("Software Issues",     true),
        ("Network Problems",    true),
        ("Account Management",  true),
        ("Security Concerns",   false),
    ];

    public static async Task SeedAsync(IServiceProvider services)
    {
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        var db = services.GetRequiredService<AppDbContext>();
        var logger = services.GetRequiredService<ILogger<AppDbContext>>();

        await SeedUsersAsync(userManager, logger);
        await SeedCategoriesAsync(db, logger);
    }

    private static async Task SeedUsersAsync(
        UserManager<ApplicationUser> userManager,
        ILogger logger)
    {
        foreach (var seed in Users)
        {
            var user = await userManager.FindByEmailAsync(seed.Email);

            if (user is null)
            {
                user = new ApplicationUser
                {
                    UserName = seed.Email,
                    Email = seed.Email,
                    DisplayName = seed.DisplayName
                };

                var createResult = await userManager.CreateAsync(user, seed.Password);
                if (!createResult.Succeeded)
                {
                    var errors = string.Join(", ", createResult.Errors.Select(e => e.Description));
                    logger.LogError("Failed to seed user {Email}: {Errors}", seed.Email, errors);
                    continue;
                }
            }

            if (!await userManager.IsInRoleAsync(user, seed.Role))
            {
                var roleResult = await userManager.AddToRoleAsync(user, seed.Role);
                if (!roleResult.Succeeded)
                {
                    var errors = string.Join(", ", roleResult.Errors.Select(e => e.Description));
                    logger.LogError("Failed to assign role {Role} to {Email}: {Errors}", seed.Role, seed.Email, errors);
                    continue;
                }

                logger.LogInformation("Assigned role {Role} to {Email}", seed.Role, seed.Email);
            }

            logger.LogInformation("Seeded user {Email} with role {Role}", seed.Email, seed.Role);
        }
    }

    private static async Task SeedCategoriesAsync(AppDbContext db, ILogger logger)
    {
        foreach (var (name, isActive) in Categories)
        {
            var exists = await db.Categories.AnyAsync(c => c.Name == name);
            if (exists)
                continue;

            db.Categories.Add(new Category { Name = name, IsActive = isActive });
            logger.LogInformation("Seeding category '{Name}' (active={IsActive})", name, isActive);
        }

        await db.SaveChangesAsync();
    }
}
