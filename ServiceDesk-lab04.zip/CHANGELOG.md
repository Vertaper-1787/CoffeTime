# Changelog Lab 04 vs Lab 03

## Что добавилось в Lab 04

### Backend
- Реализован Categories API:
  - GET /api/categories
  - POST /api/categories (Admin)
  - PUT /api/categories/{id} (Admin)
  - PATCH /api/categories/{id}/active (Admin)
- Реализован Users API:
  - GET /api/users (Admin)
- Реализована смена роли пользователя:
  - PUT /api/users/{id}/role (Admin)
- Добавлены seed-данные:
  - роли (Student, Operator, Admin)
  - demo-пользователи
  - demo-категории
- Добавлено логирование через ILogger

### Frontend
- Добавлены страницы администратора:
  - CategoriesPage
  - UsersPage
- Реализована работа с API через TanStack Query
- Добавлены формы создания и редактирования
- Добавлены уведомления (Ant Design message)

### Архитектура
- Введено разделение ролей:
  - Student
  - Operator
  - Admin
- Реализован role-based UI:
  - меню
  - доступ к страницам
- Подготовка структуры под Tickets (Lab 05)

---

## Что изменилось

- Аутентификация теперь используется во всём приложении
- Добавлены реальные защищённые страницы
- JWT влияет на отображение UI (а не только backend)

---

## Важно для студентов

- После смены роли необходимо заново войти в систему
- Параметр includeInactive доступен только Operator/Admin
- Название категории должно быть уникальным
