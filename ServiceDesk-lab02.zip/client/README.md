# ServiceDesk
## Каркас клиентской части (Frontend Scaffold)

## Название
Каркас клиентского приложения

## Цель
Подготовка клиентского приложения ServiceDesk на базе React + TypeScript с маршрутизацией, layout, role-based навигацией, базовыми guards и стандартными UI-состояниями без подключения реального backend.

## Задачи
- создание и настройка frontend-проекта на Vite + React + TypeScript
- подключение Ant Design
- настройка React Router и карты маршрутов
- реализация общего layout приложения
- подготовка role-based навигации для Student, Operator и Admin
- добавление заглушек страниц для будущих лабораторных работ
- подключение AuthContext в виде клиентского каркаса
- подключение QueryClientProvider для дальнейшей работы с API
- реализация типовых UI-состояний: loading, empty, error, validation, 403 и 404

---

# 1. Общая идея

Во второй лабораторной работе формируется базовая архитектура клиентской части, на которую будут опираться все следующие лабораторные работы.

На этом этапе:
- реальный backend ещё не подключён
- HTTP API ещё не используется
- страницы в основном представлены заглушками
- авторизация работает в демонстрационном режиме через локальный token

Но уже подготовлены:
- структура проекта
- набор маршрутов под все роли
- базовый AppLayout
- AuthContext
- guards доступа
- общие UI-компоненты для состояний страницы
- точка подключения TanStack Query

Именно эта лабораторная работа задаёт "скелет" будущего приложения.

---

# 2. Что находится в архиве

После распаковки архива присутствует следующая структура:

```text
client/
├─ .prettierrc
├─ eslint.config.js
├─ index.html
├─ package.json
├─ README.md
├─ tsconfig.json
├─ tsconfig.node.json
├─ vite.config.ts
└─ src/
   ├─ App.tsx
   ├─ main.tsx
   ├─ vite-env.d.ts
   ├─ components/
   │  ├─ AppLayout.tsx
   │  ├─ PageEmpty.tsx
   │  ├─ PageError.tsx
   │  ├─ PageLoading.tsx
   │  ├─ PageNotFound.tsx
   │  ├─ PageValidation.tsx
   │  ├─ RequireAuth.tsx
   │  └─ RequireRole.tsx
   ├─ contexts/
   │  └─ AuthContext.tsx
   └─ pages/
      ├─ ForbiddenPage.tsx
      ├─ LoginPage.tsx
      ├─ RegisterPage.tsx
      ├─ TicketDetailPage.tsx
      ├─ admin/
      │  ├─ CategoriesPage.tsx
      │  └─ UsersPage.tsx
      ├─ operator/
      │  ├─ QueueAssignedPage.tsx
      │  ├─ QueueNewPage.tsx
      │  └─ QueueResolvedPage.tsx
      └─ student/
         ├─ NewTicketPage.tsx
         └─ TicketsPage.tsx
```

Также в архиве присутствует пустая папка `server/`, что согласуется с идеей курса: на Lab 2 создаётся только каркас client-side части.

---

# 3. Технологический стек

По `package.json` в проекте используются:

## Основные зависимости
- `react` ^18
- `react-dom` ^18
- `react-router-dom` ^6
- `antd` ^5
- `@tanstack/react-query` ^5

## Dev dependencies
- `vite` ^6
- `typescript` ^5
- `@vitejs/plugin-react` ^4
- `eslint` ^9
- `typescript-eslint` ^8
- `eslint-plugin-react` ^7
- `eslint-plugin-react-hooks` ^5
- `eslint-config-prettier` ^10
- `prettier` ^3

Это означает, что каркас уже подготовлен под современный frontend-стек, который затем будет без смены архитектуры расширяться в следующих лабораторных работах.

---

# 4. Скрипты проекта

В `package.json` настроены следующие команды:

```json
"scripts": {
  "dev": "vite",
  "build": "tsc && vite build",
  "preview": "vite preview",
  "lint": "eslint src",
  "format": "prettier --write src"
}
```

## Назначение скриптов
- `npm run dev` — запуск dev-сервера Vite
- `npm run build` — проверка TypeScript и production-сборка
- `npm run preview` — локальный просмотр production-сборки
- `npm run lint` — проверка кода через ESLint
- `npm run format` — форматирование файлов в `src` через Prettier

---

# 5. Что уже реализовано в проекте

## Реально реализовано
- базовое React-приложение на TypeScript
- подключение Ant Design reset styles
- подключение QueryClientProvider
- подключение AuthProvider
- конфигурация React Router
- общий layout приложения
- role-based боковое меню
- заглушки страниц для всех основных разделов
- guard для наличия token (`RequireAuth`)
- guard для проверки роли (`RequireRole`)
- страницы 403 и 404
- общие компоненты состояний страницы
- демонстрационный вход через выбор роли на LoginPage

## Что пока не реализовано
- реальные формы логина и регистрации
- HTTP API
- запрос `/api/auth/me`
- восстановление сессии через backend
- реальные данные на страницах тикетов, очередей и администрирования
- обработка ProblemDetails от сервера

---

# 6. Точка входа приложения

Файл:

```text
src/main.tsx
```

Содержимое показывает следующую последовательность инициализации:

1. создаётся `QueryClient`
2. приложение оборачивается в `QueryClientProvider`
3. приложение оборачивается в `AuthProvider`
4. рендерится `App`

Фактически уже подготовлены две важные точки расширения:
- глобальный контекст авторизации
- инфраструктура для загрузки серверных данных через TanStack Query

Это особенно важно, потому что в Lab 3 будет подключаться реальная авторизация, а в Lab 4–7 — запросы к API.

---

# 7. Маршрутизация

Файл:

```text
src/App.tsx
```

В проекте уже описана почти полная карта маршрутов будущего приложения.

## Публичные маршруты
- `/login`
- `/register`

## Приватные маршруты внутри `RequireAuth` и `AppLayout`

### Student
- `/tickets`
- `/tickets/new`

### Shared
- `/tickets/:id` — доступен Student и Operator

### Operator
- `/queue/new`
- `/queue/assigned`
- `/queue/resolved`

### Admin
- `/admin/categories`
- `/admin/users`

## Дополнительно
- `/` → redirect на `/tickets`
- `*` → `PageNotFound`

## Что важно в этой маршрутизации
Каркас уже заранее учитывает все будущие лабораторные работы:
- студенческие страницы
- операторские очереди
- административные разделы
- карточку заявки

Это хороший признак целостной архитектуры: на Lab 2 маршруты уже отражают итоговую структуру системы, хотя сами страницы ещё пустые.

---

# 8. AppLayout

Файл:

```text
src/components/AppLayout.tsx
```

## Что реализовано
Компонент использует `Layout`, `Header`, `Sider`, `Content` из Ant Design и отвечает за общую оболочку приложения.

### Header
В верхней части отображаются:
- название системы `Service Desk`
- имя текущего пользователя или `Guest`
- роль
- ссылка `Logout`

### Sider
Левая боковая панель строится динамически в зависимости от роли.

### Content
В центральной части через `<Outlet />` рендерится текущая страница маршрута.

## Меню по ролям

### Student
- My Tickets
- New Ticket

### Operator
- New
- Assigned to Me
- Resolved

### Admin
- Categories
- Users

## Вывод
AppLayout уже реализует очень важную идею курса: у каждой роли своя навигация и свой основной рабочий сценарий.

---

# 9. AuthContext

Файл:

```text
src/contexts/AuthContext.tsx
```

## Что уже есть
Определены:
- тип `Role = 'Student' | 'Operator' | 'Admin'`
- интерфейс `AuthUser`
- состояние `user`
- состояние `role`
- состояние `token`
- `isAuthenticated`
- функции `login`, `logout`, `init`

## Как это работает сейчас
### token
Инициализируется из `localStorage`:

```ts
const [token, setToken] = useState<string | null>(() => localStorage.getItem('token'));
```

### login
Функция:
- записывает token в `localStorage`
- обновляет состояние `token`
- сохраняет `user`
- сохраняет `role`

### logout
Функция:
- удаляет token из `localStorage`
- очищает `token`, `user`, `role`

### init
Пока является заглушкой:

```ts
const init = () => {
  // stub: will read token from localStorage and restore session in Lab 3
};
```

## Вывод
AuthContext на Lab 2 уже существует, но ещё не интегрирован с backend. Это полностью соответствует логике курса: сначала подготавливается структура, затем в Lab 3 подключается реальная аутентификация.

---

# 10. Guards доступа

## 10.1 RequireAuth
Файл:

```text
src/components/RequireAuth.tsx
```

Проверка выполняется очень просто:
- token читается из `localStorage`
- если token отсутствует, пользователь перенаправляется на `/login`

```ts
const token = localStorage.getItem('token');
if (!token) return <Navigate to="/login" replace />;
```

Это временный механизм для Lab 2. На следующей лабораторной работе логика будет опираться уже не только на наличие token, но и на реальное восстановление пользователя через `/api/auth/me`.

## 10.2 RequireRole
Файл:

```text
src/components/RequireRole.tsx
```

Компонент:
- получает список разрешённых ролей
- читает текущую роль из `AuthContext`
- если роль отсутствует или не входит в список, возвращает `ForbiddenPage`

Это уже полноценная role-based защита на уровне маршрутов.

---

# 11. Страницы

## 11.1 LoginPage
Файл:

```text
src/pages/LoginPage.tsx
```

### Что реализовано
LoginPage уже не пустая. В ней есть демонстрационный вход по ролям.

На странице:
- карточка Ant Design
- заголовок `Service Desk`
- подпись `Demo — select a role to continue`
- три кнопки:
  - Login as Student
  - Login as Operator
  - Login as Admin

### Как работает
При выборе роли вызывается:

```ts
login('dev-token', { id: 'dev', displayName: `${role} Demo` }, role);
```

После этого выполняется переход:
- Student → `/tickets`
- Operator → `/queue/new`
- Admin → `/admin/categories`

### Вывод
Для Lab 2 это очень удачное решение: без backend уже можно проверить layout, меню, guards и маршрутизацию.

---

## 11.2 RegisterPage
Файл:

```text
src/pages/RegisterPage.tsx
```

Сейчас страница представлена простой заглушкой:

```tsx
export default function RegisterPage() {
  return <div>RegisterPage</div>;
}
```

Это означает, что реальная форма регистрации ещё не сделана и будет полноценной частью следующей лабораторной работы.

---

## 11.3 Student pages

### `src/pages/student/TicketsPage.tsx`
```tsx
export default function TicketsPage() {
  return <div>TicketsPage</div>;
}
```

### `src/pages/student/NewTicketPage.tsx`
```tsx
export default function NewTicketPage() {
  return <div>NewTicketPage</div>;
}
```

Обе страницы пока являются заглушками. Их наполнение ожидается в Lab 5.

---

## 11.4 Operator pages

### `QueueNewPage.tsx`
### `QueueAssignedPage.tsx`
### `QueueResolvedPage.tsx`

Все три страницы пока являются заглушками и подготавливают будущий workflow оператора, который будет реализован в Lab 6.

---

## 11.5 Admin pages

### `CategoriesPage.tsx`
### `UsersPage.tsx`

Обе страницы сейчас пустые и предназначены для Lab 4.

---

## 11.6 TicketDetailPage

Файл:

```text
src/pages/TicketDetailPage.tsx
```

Также пока является заглушкой. В будущем будет использоваться для просмотра одной заявки и затем для комментариев.

---

# 12. Компоненты состояний страницы

В `src/components` уже подготовлен полезный набор универсальных UI-компонентов.

## PageLoading
На основе `Spin` показывает загрузку по центру.

## PageEmpty
На основе `Empty` показывает отсутствие данных.

## PageError
На основе `Alert` показывает ошибку страницы.

## PageValidation
На основе `Alert` и списка `<ul>` показывает набор ошибок валидации.

## PageNotFound
Страница 404 на основе `Result`.

## ForbiddenPage
Страница 403 на основе `Result`.

## Вывод
Это хороший задел под единообразный UX. В следующих лабораторных эти компоненты уже можно использовать без повторной вёрстки.

---

# 13. Настройки Vite

Файл:

```text
vite.config.ts
```

Сейчас настроено:

```ts
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
  },
});
```

## Что это означает
- приложение запускается на `http://localhost:5173`
- dev proxy к backend пока не настроен

Это нормально для Lab 2, потому что реальный backend ещё не используется. В Lab 3 сюда обычно добавляется proxy на `/api`.

---

# 14. ESLint и Prettier

## ESLint
Файл:

```text
eslint.config.js
```

Подключены:
- базовые правила JavaScript
- рекомендации `typescript-eslint`
- `eslint-plugin-react`
- `eslint-plugin-react-hooks`
- совместимость с Prettier

Проверяются:
- hooks rules
- структура React/TS-кода
- общее качество кода

## Prettier
Файл:

```text
.prettierrc
```

Присутствует конфигурация форматирования. Значит, проект уже ориентирован на единый код-стиль.

---

# 15. Что именно уже можно проверить в браузере

Даже без backend уже доступны следующие сценарии:

## Сценарий 1. Вход как Student
- открывается `/login`
- выбирается `Login as Student`
- записывается `dev-token`
- открывается `/tickets`
- в Header отображается `Student Demo · Student`
- в меню доступны `My Tickets` и `New Ticket`

## Сценарий 2. Вход как Operator
- открывается `/queue/new`
- в меню отображаются три operator-раздела

## Сценарий 3. Вход как Admin
- открывается `/admin/categories`
- в меню отображаются `Categories` и `Users`

## Сценарий 4. Проверка guard по token
- при отсутствии token приватные маршруты переводят на `/login`

## Сценарий 5. Проверка guard по role
- при неподходящей роли отображается 403 страница

## Сценарий 6. Logout
- token удаляется из `localStorage`
- выполняется переход на `/login`

---

# 16. Что в проекте особенно хорошо подготовлено

## 1. Маршруты заданы заранее под весь курс
Это снижает количество будущих перестроек.

## 2. Role-based layout уже работает
Можно сразу визуально проверить различие ролей.

## 3. AuthContext уже существует
В Lab 3 не придётся начинать с нуля.

## 4. UI state components вынесены отдельно
Страницы в следующих лабораторных будут строиться быстрее и единообразнее.

## 5. TanStack Query подключён заранее
Дальнейшая интеграция API будет мягкой и без перестройки точки входа.

---

# 17. Что в текущем каркасе пока условно или временно

## 1. LoginPage — демонстрационная, а не реальная
Вместо формы логина пока используется выбор роли.

## 2. RegisterPage ещё не реализована
Это ожидаемая часть Lab 3.

## 3. init() пока пустой
Сессия восстанавливается только по факту наличия token, но не через запрос к серверу.

## 4. RequireAuth читает token напрямую из localStorage
Для Lab 2 это допустимо, но позже логика станет более строгой.

## 5. Почти все рабочие страницы пока заглушки
Это соответствует идее каркаса и не является ошибкой.

---

# 18. Связь с последующими лабораторными работами

## Lab 3
Сюда будут добавлены:
- backend auth
- реальные `/api/auth/login`, `/api/auth/register`, `/api/auth/me`
- реальная форма LoginPage
- реальная RegisterPage
- реализация `AuthContext.init()`
- dev proxy на `/api`

## Lab 4
Будут наполнены:
- `CategoriesPage`
- `UsersPage`

## Lab 5
Будут наполнены:
- `TicketsPage`
- `NewTicketPage`
- `TicketDetailPage`

## Lab 6
Будут наполнены:
- `QueueNewPage`
- `QueueAssignedPage`
- `QueueResolvedPage`

Таким образом, Lab 2 уже содержит практически весь маршрутный и визуальный каркас будущей системы.

---

# 19. Запуск проекта

## Установка зависимостей

```bash
npm install
```

## Запуск dev-сервера

```bash
npm run dev
```

## Сборка проекта

```bash
npm run build
```

## Проверка линтером

```bash
npm run lint
```

## Форматирование

```bash
npm run format
```

По текущей конфигурации приложение запускается на:

```text
http://localhost:5173
```

---

# 20. Критерии готовности лабораторной работы

Лабораторную работу можно считать выполненной, если:

- создан frontend-проект на React + TypeScript + Vite
- подключён Ant Design
- настроен React Router
- существует общий AppLayout
- настроены маршруты для всех ролей
- реализованы RequireAuth и RequireRole
- существует AuthContext с token/user/role
- работает демонстрационный вход по ролям
- доступны заглушки страниц для Student, Operator и Admin
- присутствуют компоненты PageLoading, PageEmpty, PageError, PageValidation, 403 и 404
- приложение собирается и запускается