using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using ServiceDesk.API.DTOs.Categories;
using ServiceDesk.API.Tests.Infrastructure;

namespace ServiceDesk.API.Tests;

public class CategoriesIntegrationTests : IntegrationTestBase, IClassFixture<ServiceDeskWebApplicationFactory>
{
    public CategoriesIntegrationTests(ServiceDeskWebApplicationFactory factory) : base(factory)
    {
    }

    [Fact]
    public async Task CreateCategory_WithValidName_AsAdmin_Succeeds()
    {
        var admin = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Admin");
        var adminToken = await TestAuthHelper.GetAccessTokenAsync(Client, admin.Email, admin.Password);
        SetBearerToken(adminToken);

        var response = await Client.PostAsJsonAsync("/api/categories",
            new CreateCategoryRequest { Name = "Printers" });

        response.StatusCode.Should().Be(HttpStatusCode.Created);

        var created = await response.Content.ReadFromJsonAsync<CategoryResponse>();
        created.Should().NotBeNull();
        created!.Name.Should().Be("Printers");
        created.IsActive.Should().BeTrue();
    }

    [Fact]
    public async Task CreateCategory_WithDuplicateName_AsAdmin_Returns400()
    {
        var admin = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Admin");
        var adminToken = await TestAuthHelper.GetAccessTokenAsync(Client, admin.Email, admin.Password);
        SetBearerToken(adminToken);

        var firstResponse = await Client.PostAsJsonAsync("/api/categories",
            new CreateCategoryRequest { Name = "Networking" });
        firstResponse.StatusCode.Should().Be(HttpStatusCode.Created);

        var duplicateResponse = await Client.PostAsJsonAsync("/api/categories",
            new CreateCategoryRequest { Name = "Networking" });

        duplicateResponse.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public async Task CreateCategory_WithEmptyOrWhitespaceName_AsAdmin_Returns400(string name)
    {
        var admin = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Admin");
        var adminToken = await TestAuthHelper.GetAccessTokenAsync(Client, admin.Email, admin.Password);
        SetBearerToken(adminToken);

        var response = await Client.PostAsJsonAsync("/api/categories",
            new CreateCategoryRequest { Name = name });

        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task StudentGetCategories_WithIncludeInactiveTrue_ReturnsOnlyActive()
    {
        var admin = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Admin");
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var adminToken = await TestAuthHelper.GetAccessTokenAsync(Client, admin.Email, admin.Password);
        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);

        SetBearerToken(adminToken);
        var activeResponse = await Client.PostAsJsonAsync("/api/categories",
            new CreateCategoryRequest { Name = $"Active {Guid.NewGuid():N}" });
        activeResponse.StatusCode.Should().Be(HttpStatusCode.Created);
        var activeCategory = await activeResponse.Content.ReadFromJsonAsync<CategoryResponse>();
        activeCategory.Should().NotBeNull();

        var inactiveResponse = await Client.PostAsJsonAsync("/api/categories",
            new CreateCategoryRequest { Name = $"Inactive {Guid.NewGuid():N}" });
        inactiveResponse.StatusCode.Should().Be(HttpStatusCode.Created);
        var inactiveCategory = await inactiveResponse.Content.ReadFromJsonAsync<CategoryResponse>();
        inactiveCategory.Should().NotBeNull();

        var deactivateResponse = await Client.PatchAsJsonAsync(
            $"/api/categories/{inactiveCategory!.Id}/active",
            new SetActiveCategoryRequest { IsActive = false });
        deactivateResponse.StatusCode.Should().Be(HttpStatusCode.OK);

        SetBearerToken(studentToken);
        var getResponse = await Client.GetAsync("/api/categories?includeInactive=true");
        getResponse.StatusCode.Should().Be(HttpStatusCode.OK);

        var categories = await getResponse.Content.ReadFromJsonAsync<List<CategoryResponse>>();
        categories.Should().NotBeNull();
        categories!.Should().OnlyContain(c => c.IsActive);
        categories.Should().ContainSingle(c => c.Id == activeCategory!.Id);
        categories.Should().NotContain(c => c.Id == inactiveCategory.Id);
    }
}
