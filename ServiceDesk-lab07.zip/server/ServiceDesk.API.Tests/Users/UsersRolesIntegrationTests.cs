using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using ServiceDesk.API.DTOs.Users;
using ServiceDesk.API.Tests.Infrastructure;

namespace ServiceDesk.API.Tests;

public class UsersRolesIntegrationTests : IntegrationTestBase, IClassFixture<ServiceDeskWebApplicationFactory>
{
    public UsersRolesIntegrationTests(ServiceDeskWebApplicationFactory factory) : base(factory)
    {
    }

    [Fact]
    public async Task ChangeUserRole_WithValidData_SucceedsAndLeavesExactlyOneRole()
    {
        var admin = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Admin");
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var adminToken = await TestAuthHelper.GetAccessTokenAsync(Client, admin.Email, admin.Password);
        SetBearerToken(adminToken);

        var response = await Client.PutAsJsonAsync($"/api/users/{student.Id}/role",
            new UpdateUserRoleRequest { Role = "Operator" });

        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var updated = await response.Content.ReadFromJsonAsync<UserResponse>();
        updated.Should().NotBeNull();
        updated!.Role.Should().Be("Operator");

        var roles = await TestDataSeeder.GetUserRolesAsync(Factory, student.Id);
        roles.Should().ContainSingle().Which.Should().Be("Operator");
    }

    [Fact]
    public async Task ChangeUserRole_ForNonexistentUser_Returns404()
    {
        var admin = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Admin");
        var adminToken = await TestAuthHelper.GetAccessTokenAsync(Client, admin.Email, admin.Password);
        SetBearerToken(adminToken);

        var response = await Client.PutAsJsonAsync($"/api/users/{Guid.NewGuid():N}/role",
            new UpdateUserRoleRequest { Role = "Operator" });

        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task ChangeUserRole_WithInvalidRoleValue_Returns400()
    {
        var admin = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Admin");
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var adminToken = await TestAuthHelper.GetAccessTokenAsync(Client, admin.Email, admin.Password);
        SetBearerToken(adminToken);

        var response = await Client.PutAsJsonAsync($"/api/users/{student.Id}/role",
            new UpdateUserRoleRequest { Role = "Manager" });

        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }
}
