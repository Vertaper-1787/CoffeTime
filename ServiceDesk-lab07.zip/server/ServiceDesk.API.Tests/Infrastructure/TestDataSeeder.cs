using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using ServiceDesk.API.Domain;
using ServiceDesk.API.Infrastructure.Data;

namespace ServiceDesk.API.Tests.Infrastructure;

public sealed record TestUser(string Id, string Email, string Password, string DisplayName, string Role);

public static class TestDataSeeder
{
    public static async Task EnsureDefaultRolesAsync(ServiceDeskWebApplicationFactory factory)
    {
        using var scope = factory.Services.CreateScope();
        var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

        foreach (var role in new[] { "Student", "Operator", "Admin" })
        {
            if (await roleManager.RoleExistsAsync(role))
            {
                continue;
            }

            var createRoleResult = await roleManager.CreateAsync(new IdentityRole(role));
            EnsureSucceeded(createRoleResult, $"create role '{role}'");
        }
    }

    public static async Task<TestUser> CreateUserWithRoleAsync(
        ServiceDeskWebApplicationFactory factory,
        string role,
        string? email = null,
        string? displayName = null,
        string password = "Password123!")
    {
        email ??= $"{role.ToLowerInvariant()}.{Guid.NewGuid():N}@test.local";
        displayName ??= $"{role} User {Guid.NewGuid():N}";

        await EnsureDefaultRolesAsync(factory);

        using var scope = factory.Services.CreateScope();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

        var user = new ApplicationUser
        {
            UserName = email,
            Email = email,
            DisplayName = displayName
        };

        var createUserResult = await userManager.CreateAsync(user, password);
        EnsureSucceeded(createUserResult, $"create user '{email}'");

        var addRoleResult = await userManager.AddToRoleAsync(user, role);
        EnsureSucceeded(addRoleResult, $"add user '{email}' to role '{role}'");

        return new TestUser(user.Id, email, password, displayName, role);
    }

    public static async Task<int> CreateActiveCategoryAsync(
        ServiceDeskWebApplicationFactory factory,
        string? name = null)
    {
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        var category = new Category
        {
            Name = name ?? $"Category {Guid.NewGuid():N}",
            IsActive = true
        };

        db.Categories.Add(category);
        await db.SaveChangesAsync();
        return category.Id;
    }

    public static async Task<IReadOnlyList<string>> GetUserRolesAsync(
        ServiceDeskWebApplicationFactory factory,
        string userId)
    {
        using var scope = factory.Services.CreateScope();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var user = await userManager.FindByIdAsync(userId)
            ?? throw new InvalidOperationException($"User '{userId}' was not found.");

        var roles = await userManager.GetRolesAsync(user);
        return roles.ToList();
    }

    private static void EnsureSucceeded(IdentityResult result, string operation)
    {
        if (result.Succeeded)
            return;

        var errors = string.Join(", ", result.Errors.Select(e => e.Description));
        throw new InvalidOperationException($"Failed to {operation}: {errors}");
    }
}
