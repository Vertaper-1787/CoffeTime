using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using ServiceDesk.API.DTOs.Tickets;
using ServiceDesk.API.Tests.Infrastructure;

namespace ServiceDesk.API.Tests;

public class TicketsStatusIntegrationTests : IntegrationTestBase, IClassFixture<ServiceDeskWebApplicationFactory>
{
    public TicketsStatusIntegrationTests(ServiceDeskWebApplicationFactory factory) : base(factory)
    {
    }

    [Fact]
    public async Task OperatorCannotChangeStatusOfTicketAssignedToAnotherOperator_Returns403()
    {
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var operator1 = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");
        var operator2 = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");

        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);
        var operator1Token = await TestAuthHelper.GetAccessTokenAsync(Client, operator1.Email, operator1.Password);
        var operator2Token = await TestAuthHelper.GetAccessTokenAsync(Client, operator2.Email, operator2.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentToken, categoryId);

        SetBearerToken(operator1Token);
        var assignResponse = await Client.PostAsync($"/api/tickets/{created.Id}/assign-to-me", null);
        assignResponse.StatusCode.Should().Be(HttpStatusCode.OK);

        SetBearerToken(operator2Token);
        var changeStatusResponse = await Client.PostAsJsonAsync(
            $"/api/tickets/{created.Id}/status",
            new ChangeStatusRequest("Resolved"));

        changeStatusResponse.StatusCode.Should().Be(HttpStatusCode.Forbidden);
    }

    [Fact]
    public async Task OperatorChangeStatus_InProgressToResolved_Succeeds()
    {
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var operatorUser = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");

        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);
        var operatorToken = await TestAuthHelper.GetAccessTokenAsync(Client, operatorUser.Email, operatorUser.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentToken, categoryId);

        SetBearerToken(operatorToken);
        var assignResponse = await Client.PostAsync($"/api/tickets/{created.Id}/assign-to-me", null);
        assignResponse.StatusCode.Should().Be(HttpStatusCode.OK);

        var changeStatusResponse = await Client.PostAsJsonAsync(
            $"/api/tickets/{created.Id}/status",
            new ChangeStatusRequest("Resolved"));

        changeStatusResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        var updated = await changeStatusResponse.Content.ReadFromJsonAsync<TicketResponse>();
        updated.Should().NotBeNull();
        updated!.Status.Should().Be("Resolved");
    }

    [Fact]
    public async Task OperatorChangeStatus_ToSameStatus_Returns400()
    {
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var operatorUser = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");

        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);
        var operatorToken = await TestAuthHelper.GetAccessTokenAsync(Client, operatorUser.Email, operatorUser.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentToken, categoryId);

        SetBearerToken(operatorToken);
        var assignResponse = await Client.PostAsync($"/api/tickets/{created.Id}/assign-to-me", null);
        assignResponse.StatusCode.Should().Be(HttpStatusCode.OK);

        var sameStatusResponse = await Client.PostAsJsonAsync(
            $"/api/tickets/{created.Id}/status",
            new ChangeStatusRequest("InProgress"));

        sameStatusResponse.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task OperatorChangeStatus_WithInvalidWorkflowTransition_Returns400()
    {
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var operatorUser = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");

        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);
        var operatorToken = await TestAuthHelper.GetAccessTokenAsync(Client, operatorUser.Email, operatorUser.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentToken, categoryId);

        SetBearerToken(operatorToken);
        var assignResponse = await Client.PostAsync($"/api/tickets/{created.Id}/assign-to-me", null);
        assignResponse.StatusCode.Should().Be(HttpStatusCode.OK);

        var invalidTransitionResponse = await Client.PostAsJsonAsync(
            $"/api/tickets/{created.Id}/status",
            new ChangeStatusRequest("Closed"));

        invalidTransitionResponse.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    private async Task<TicketResponse> CreateTicketAsStudentAsync(string studentToken, int categoryId)
    {
        SetBearerToken(studentToken);
        var response = await Client.PostAsJsonAsync("/api/tickets", new CreateTicketRequest(
            $"Ticket {Guid.NewGuid():N}",
            "Integration test ticket description",
            "Medium",
            categoryId));

        response.StatusCode.Should().Be(HttpStatusCode.Created);

        var created = await response.Content.ReadFromJsonAsync<TicketResponse>();
        created.Should().NotBeNull();
        return created!;
    }
}
