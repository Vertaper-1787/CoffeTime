using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using ServiceDesk.API.DTOs.Tickets;
using ServiceDesk.API.Tests.Infrastructure;

namespace ServiceDesk.API.Tests;

public class TicketsIntegrationTests : IntegrationTestBase, IClassFixture<ServiceDeskWebApplicationFactory>
{
    public TicketsIntegrationTests(ServiceDeskWebApplicationFactory factory) : base(factory)
    {
    }

    [Fact]
    public async Task StudentCreatesTicket_Succeeds_WithStatusNew()
    {
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentToken, categoryId);

        created.Status.Should().Be("New");
    }

    [Fact]
    public async Task StudentCannotAccessAnotherStudentsTicket_Returns404()
    {
        var studentA = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var studentB = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var studentAToken = await TestAuthHelper.GetAccessTokenAsync(Client, studentA.Email, studentA.Password);
        var studentBToken = await TestAuthHelper.GetAccessTokenAsync(Client, studentB.Email, studentB.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentAToken, categoryId);

        SetBearerToken(studentBToken);
        var response = await Client.GetAsync($"/api/tickets/{created.Id}");

        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task OperatorAssignToMe_ForNewUnassignedTicket_Succeeds()
    {
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var operatorUser = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");

        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);
        var operatorToken = await TestAuthHelper.GetAccessTokenAsync(Client, operatorUser.Email, operatorUser.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentToken, categoryId);

        SetBearerToken(operatorToken);
        var assignResponse = await Client.PostAsync($"/api/tickets/{created.Id}/assign-to-me", null);

        assignResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        var assigned = await assignResponse.Content.ReadFromJsonAsync<TicketResponse>();
        assigned.Should().NotBeNull();
        assigned!.Status.Should().Be("InProgress");
        assigned.Assignee.Should().NotBeNull();
        assigned.Assignee!.Id.Should().Be(operatorUser.Id);
    }

    [Fact]
    public async Task OperatorAssignToMe_WhenAssignedToAnotherOperator_Returns409()
    {
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var operator1 = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");
        var operator2 = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");

        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);
        var operator1Token = await TestAuthHelper.GetAccessTokenAsync(Client, operator1.Email, operator1.Password);
        var operator2Token = await TestAuthHelper.GetAccessTokenAsync(Client, operator2.Email, operator2.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentToken, categoryId);

        SetBearerToken(operator1Token);
        var firstAssign = await Client.PostAsync($"/api/tickets/{created.Id}/assign-to-me", null);
        firstAssign.StatusCode.Should().Be(HttpStatusCode.OK);

        SetBearerToken(operator2Token);
        var secondAssign = await Client.PostAsync($"/api/tickets/{created.Id}/assign-to-me", null);

        secondAssign.StatusCode.Should().Be(HttpStatusCode.Conflict);
    }

    private async Task<TicketResponse> CreateTicketAsStudentAsync(string studentToken, int categoryId)
    {
        SetBearerToken(studentToken);
        var response = await Client.PostAsJsonAsync("/api/tickets", new CreateTicketRequest(
            $"Ticket {Guid.NewGuid():N}",
            "Integration test ticket description",
            "Medium",
            categoryId));

        response.StatusCode.Should().Be(HttpStatusCode.Created);

        var created = await response.Content.ReadFromJsonAsync<TicketResponse>();
        created.Should().NotBeNull();
        return created!;
    }
}
