using System.Net;
using System.Net.Http.Json;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using ServiceDesk.API.Domain;
using ServiceDesk.API.DTOs.Tickets;
using ServiceDesk.API.Infrastructure.Data;
using ServiceDesk.API.Tests.Infrastructure;

namespace ServiceDesk.API.Tests;

public class TicketsRejectIntegrationTests : IntegrationTestBase, IClassFixture<ServiceDeskWebApplicationFactory>
{
    public TicketsRejectIntegrationTests(ServiceDeskWebApplicationFactory factory) : base(factory)
    {
    }

    [Fact]
    public async Task RejectingClosedTicket_Returns400()
    {
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var operatorUser = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");

        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);
        var operatorToken = await TestAuthHelper.GetAccessTokenAsync(Client, operatorUser.Email, operatorUser.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentToken, categoryId);
        await SetTicketStatusAsync(created.Id, TicketStatus.Closed);

        SetBearerToken(operatorToken);
        var rejectResponse = await Client.PostAsJsonAsync(
            $"/api/tickets/{created.Id}/reject",
            new RejectRequest("Out of support scope"));

        rejectResponse.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task RejectingRejectedTicket_Returns400()
    {
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var operatorUser = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");

        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);
        var operatorToken = await TestAuthHelper.GetAccessTokenAsync(Client, operatorUser.Email, operatorUser.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentToken, categoryId);
        await SetTicketStatusAsync(created.Id, TicketStatus.Rejected);

        SetBearerToken(operatorToken);
        var rejectResponse = await Client.PostAsJsonAsync(
            $"/api/tickets/{created.Id}/reject",
            new RejectRequest("Out of support scope"));

        rejectResponse.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }

    [Fact]
    public async Task RejectingTicketAssignedToAnotherOperator_Returns409()
    {
        var student = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Student");
        var operator1 = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");
        var operator2 = await TestDataSeeder.CreateUserWithRoleAsync(Factory, "Operator");

        var studentToken = await TestAuthHelper.GetAccessTokenAsync(Client, student.Email, student.Password);
        var operator1Token = await TestAuthHelper.GetAccessTokenAsync(Client, operator1.Email, operator1.Password);
        var operator2Token = await TestAuthHelper.GetAccessTokenAsync(Client, operator2.Email, operator2.Password);
        var categoryId = await TestDataSeeder.CreateActiveCategoryAsync(Factory);

        var created = await CreateTicketAsStudentAsync(studentToken, categoryId);

        SetBearerToken(operator1Token);
        var assignResponse = await Client.PostAsync($"/api/tickets/{created.Id}/assign-to-me", null);
        assignResponse.StatusCode.Should().Be(HttpStatusCode.OK);

        SetBearerToken(operator2Token);
        var rejectResponse = await Client.PostAsJsonAsync(
            $"/api/tickets/{created.Id}/reject",
            new RejectRequest("Out of support scope"));

        rejectResponse.StatusCode.Should().Be(HttpStatusCode.Conflict);
    }

    private async Task<TicketResponse> CreateTicketAsStudentAsync(string studentToken, int categoryId)
    {
        SetBearerToken(studentToken);
        var response = await Client.PostAsJsonAsync("/api/tickets", new CreateTicketRequest(
            $"Ticket {Guid.NewGuid():N}",
            "Integration test ticket description",
            "Medium",
            categoryId));

        response.StatusCode.Should().Be(HttpStatusCode.Created);

        var created = await response.Content.ReadFromJsonAsync<TicketResponse>();
        created.Should().NotBeNull();
        return created!;
    }

    private async Task SetTicketStatusAsync(int ticketId, TicketStatus status)
    {
        using var scope = Factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();

        var ticket = await db.Tickets.FirstAsync(t => t.Id == ticketId);
        ticket.Status = status;
        ticket.RejectedReason = status == TicketStatus.Rejected ? "Already rejected" : null;
        ticket.UpdatedAt = DateTimeOffset.UtcNow;

        await db.SaveChangesAsync();
    }
}
