# ServiceDesk API — Tests

## Назначение
Серверная часть тестируется с помощью интеграционных тестов для проверки бизнес-логики, авторизации и корректности работы API.

## Что реализовано
- xUnit + FluentAssertions  
- WebApplicationFactory  
- SQLite in-memory  
- Инфраструктура: Factory, Base, Seeder, AuthHelper  
- Тесты: Auth, Categories, Users/Roles, Tickets, Platform  

## Структура тестов
```
server/ServiceDesk.API.Tests/
  Infrastructure/
    ServiceDeskWebApplicationFactory.cs
    IntegrationTestBase.cs
    TestDataSeeder.cs
    TestAuthHelper.cs
  Auth/
    AuthIntegrationTests.cs
  Categories/
    CategoriesIntegrationTests.cs
  Users/
    UsersRolesIntegrationTests.cs
  Tickets/
    TicketsIntegrationTests.cs
    TicketsStatusIntegrationTests.cs
    TicketsRejectIntegrationTests.cs
  Platform/
    PlatformIntegrationTests.cs
```

## Как запускать тесты
```
dotnet test ServiceDesk.sln
```
