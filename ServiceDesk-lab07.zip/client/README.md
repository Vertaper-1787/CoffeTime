# ServiceDesk Client — Tests

## Назначение
Клиентская часть тестируется с помощью автоматизированных тестов для проверки пользовательских сценариев, авторизации, маршрутизации и состояний интерфейса.

## Что реализовано
- Vitest, React Testing Library, jsdom  
- setupTests.ts (jest-dom, cleanup, browser mocks)  
- renderWithProviders (QueryClientProvider + MemoryRouter)  
- тесты: login, register, routing, role-based UI, page states, auth init, logout  

## Структура тестов
```
src/__tests__/
  auth/
    LoginPage.test.tsx
    RegisterPage.test.tsx
    AuthInit.test.tsx
    Logout.test.tsx
  routing/
    RouteProtection.test.tsx
  navigation/
    RoleBasedNavigation.test.tsx
  pages/
    TicketsPageStates.test.tsx

src/test/
  setupTests.ts
  renderWithProviders.tsx
```

## Как запускать тесты
```
npm run test:run
npm run test
```
