import { screen } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { ApiError } from '../../api/client';
import { ticketsApi } from '../../api/tickets';
import TicketsPage from '../../pages/student/TicketsPage';
import { renderWithProviders } from '../../test/renderWithProviders';

vi.mock('../../api/tickets', async () => {
  const actual = await vi.importActual<typeof import('../../api/tickets')>(
    '../../api/tickets',
  );

  return {
    ...actual,
    ticketsApi: {
      ...actual.ticketsApi,
      list: vi.fn(),
    },
  };
});

const listMock = vi.mocked(ticketsApi.list);

describe('TicketsPage states', () => {
  beforeEach(() => {
    listMock.mockReset();
  });

  it('renders loading state while tickets are being fetched', () => {
    listMock.mockReturnValue(
      new Promise(() => undefined) as ReturnType<typeof ticketsApi.list>,
    );

    renderWithProviders(<TicketsPage />, { route: '/tickets' });

    expect(document.querySelector('.ant-spin')).toBeInTheDocument();
  });

  it('renders error state when loading tickets fails', async () => {
    listMock.mockRejectedValue(new ApiError(500, 'Failed to load tickets'));

    renderWithProviders(<TicketsPage />, { route: '/tickets' });

    expect(await screen.findByText('Failed to load tickets')).toBeInTheDocument();
  });

  it('renders empty state when there are no tickets', async () => {
    listMock.mockResolvedValue({
      items: [],
      total: 0,
      page: 1,
      pageSize: 20,
    });

    renderWithProviders(<TicketsPage />, { route: '/tickets' });

    expect(await screen.findByText('No tickets found')).toBeInTheDocument();
  });
});
