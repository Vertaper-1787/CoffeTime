import { screen } from '@testing-library/react';
import { Route, Routes } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import AppLayout from '../../components/AppLayout';
import { RequireRole } from '../../components/RequireRole';
import { useAuth } from '../../contexts/AuthContext';
import { renderWithProviders } from '../../test/renderWithProviders';

vi.mock('../../contexts/AuthContext', async () => {
  const actual = await vi.importActual<typeof import('../../contexts/AuthContext')>(
    '../../contexts/AuthContext',
  );

  return {
    ...actual,
    useAuth: vi.fn(),
  };
});

type AuthValue = ReturnType<typeof useAuth>;

const mockedUseAuth = vi.mocked(useAuth);

function createAuthValue(overrides: Partial<AuthValue> = {}): AuthValue {
  return {
    user: {
      id: 'u-1',
      email: 'user@example.com',
      displayName: 'Test User',
    },
    role: 'Student',
    isAuthenticated: true,
    login: vi.fn(async () => undefined),
    register: vi.fn(async () => undefined),
    logout: vi.fn(),
    init: vi.fn(async () => undefined),
    ...overrides,
  };
}

function renderLayout(route: string) {
  return renderWithProviders(
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="*" element={<div>Page Content</div>} />
      </Route>
    </Routes>,
    { route },
  );
}

describe('Role-based behavior', () => {
  beforeEach(() => {
    mockedUseAuth.mockReset();
  });

  it('shows student navigation and hides admin links for Student role', () => {
    mockedUseAuth.mockReturnValue(createAuthValue({ role: 'Student' }));

    renderLayout('/tickets');

    expect(screen.getByRole('link', { name: 'My Tickets' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'New Ticket' })).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Categories' })).not.toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'Users' })).not.toBeInTheDocument();
  });

  it('shows admin navigation and hides student links for Admin role', () => {
    mockedUseAuth.mockReturnValue(createAuthValue({ role: 'Admin' }));

    renderLayout('/admin/categories');

    expect(screen.getByRole('link', { name: 'Categories' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Users' })).toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'My Tickets' })).not.toBeInTheDocument();
    expect(screen.queryByRole('link', { name: 'New Ticket' })).not.toBeInTheDocument();
  });

  it('blocks Student from Admin-only content', () => {
    mockedUseAuth.mockReturnValue(createAuthValue({ role: 'Student' }));

    renderWithProviders(
      <Routes>
        <Route
          path="/admin-only"
          element={
            <RequireRole roles={['Admin']}>
              <div>Admin-only content</div>
            </RequireRole>
          }
        />
      </Routes>,
      { route: '/admin-only' },
    );

    expect(
      screen.getByText('You do not have permission to access this page.'),
    ).toBeInTheDocument();
    expect(screen.queryByText('Admin-only content')).not.toBeInTheDocument();
  });
});
