# Changelog Lab 06 vs Lab 05

## Что добавилось

### Backend
- Operator workflow:
  - assign тикета
  - смена статуса
  - reject тикета
- новые endpoints:
  - POST /assign
  - POST /status
  - POST /reject
- анти-логика "перехвата" тикета (409)

### Frontend
- страницы очередей оператора:
  - New
  - Assigned
  - Resolved
- кнопки действий:
  - Assign to me
  - Change status
  - Reject

### Архитектура
- разделение workflow:
  - Student создаёт тикет
  - Operator обрабатывает тикет

---

## Что изменилось

- система стала полноценной (появился processing flow)
- тикеты теперь имеют жизненный цикл

---

## Важно для студентов

- нельзя брать чужой тикет
- нельзя менять статус без назначения
- порядок проверок важен (403 → 400 → transition)
