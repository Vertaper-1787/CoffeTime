# ServiceDesk.API — Lab 06

Lab 06 добавляет workflow оператора для обработки тикетов.

## Что реализуется

### Backend

- операции оператора:
  - assign to me
  - изменение статуса
  - reject тикета

- расширение Tickets API:
  - фильтрация по статусу и assignee
  - обработка очередей

### Архитектура

- строгие проверки прав (Operator only)
- бизнес-правила вынесены в сервис

---

## API

- GET /api/tickets
- POST /api/tickets/{id}/assign
- POST /api/tickets/{id}/status
- POST /api/tickets/{id}/reject

---

## Правила и ограничения

- оператор может:
  - взять только свободный тикет
  - работать только со своими тикетами
- попытка взять чужой тикет → 409 (anti-steal)
- неверный переход статуса → 400

---

## Уже реализовано ранее

- Auth (Lab 03)
- Categories + Users (Lab 04)
- Tickets (Student) (Lab 05)
