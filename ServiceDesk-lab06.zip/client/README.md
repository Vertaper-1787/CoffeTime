# Service Desk Client — Lab 06

Lab 06 расширяет клиентскую часть, добавляя workflow оператора.

## Что реализуется

### Frontend
- Operator queue страницы:
  - QueueNewPage
  - QueueAssignedPage
  - QueueResolvedPage
- действия оператора:
  - взять тикет в работу (assign to me)
  - изменить статус тикета
  - отклонить тикет

### Архитектура
- role-based UI расширен для Operator
- разделение очередей по статусам

---

## API (используется с backend)
- GET /api/tickets (с фильтрами)
- POST /api/tickets/{id}/assign
- POST /api/tickets/{id}/status
- POST /api/tickets/{id}/reject

---

## Правила и ограничения

- оператор работает только с тикетами:
  - без исполнителя (new queue)
  - назначенными на него (assigned queue)
- запрещён "перехват" чужого тикета (anti-steal → 409)
- статус можно менять только если тикет назначен на оператора

---

## Уже реализовано ранее

- Lab 03 — Auth
- Lab 04 — Admin (categories, users)
- Lab 05 — Tickets (Student)
